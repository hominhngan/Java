public class Square {
    public float x;

    public Square()
    {
    }

    public float perimeter()
    {
        return x * 4;
    }
    public float area()
    {
        return x * x;
    }
}
